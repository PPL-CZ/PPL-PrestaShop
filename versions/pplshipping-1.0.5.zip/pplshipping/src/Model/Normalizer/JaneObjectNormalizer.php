<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class JaneObjectNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    protected $normalizers = array('PPLShipping\\Model\\Model\\ProductRulesModel' => 'PPLShipping\\Model\\Normalizer\\ProductRulesModelNormalizer', 'PPLShipping\\Model\\Model\\CategoryRulesModel' => 'PPLShipping\\Model\\Normalizer\\CategoryRulesModelNormalizer', 'PPLShipping\\Model\\Model\\ParcelDataModel' => 'PPLShipping\\Model\\Normalizer\\ParcelDataModelNormalizer', 'PPLShipping\\Model\\Model\\ParcelDataModelGps' => 'PPLShipping\\Model\\Normalizer\\ParcelDataModelGpsNormalizer', 'PPLShipping\\Model\\Model\\MyApi2' => 'PPLShipping\\Model\\Normalizer\\MyApi2Normalizer', 'PPLShipping\\Model\\Model\\WhisperSettingModel' => 'PPLShipping\\Model\\Normalizer\\WhisperSettingModelNormalizer', 'PPLShipping\\Model\\Model\\WhisperAddressModel' => 'PPLShipping\\Model\\Normalizer\\WhisperAddressModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateShipmentModel' => 'PPLShipping\\Model\\Normalizer\\UpdateShipmentModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateParcelModel' => 'PPLShipping\\Model\\Normalizer\\UpdateParcelModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateShipmentSenderModel' => 'PPLShipping\\Model\\Normalizer\\UpdateShipmentSenderModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateShipmentBankAccountModel' => 'PPLShipping\\Model\\Normalizer\\UpdateShipmentBankAccountModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateShipmentParcelModel' => 'PPLShipping\\Model\\Normalizer\\UpdateShipmentParcelModelNormalizer', 'PPLShipping\\Model\\Model\\CreateShipmentLabelBatchModel' => 'PPLShipping\\Model\\Normalizer\\CreateShipmentLabelBatchModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentLabelRefreshBatchModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentLabelRefreshBatchModelNormalizer', 'PPLShipping\\Model\\Model\\PrepareShipmentBatchModel' => 'PPLShipping\\Model\\Normalizer\\PrepareShipmentBatchModelNormalizer', 'PPLShipping\\Model\\Model\\PrepareShipmentBatchItemModel' => 'PPLShipping\\Model\\Normalizer\\PrepareShipmentBatchItemModelNormalizer', 'PPLShipping\\Model\\Model\\PrepareShipmentBatchReturnModel' => 'PPLShipping\\Model\\Normalizer\\PrepareShipmentBatchReturnModelNormalizer', 'PPLShipping\\Model\\Model\\RefreshShipmentBatchReturnModel' => 'PPLShipping\\Model\\Normalizer\\RefreshShipmentBatchReturnModelNormalizer', 'PPLShipping\\Model\\Model\\PackageModel' => 'PPLShipping\\Model\\Normalizer\\PackageModelNormalizer', 'PPLShipping\\Model\\Model\\ParcelAddressModel' => 'PPLShipping\\Model\\Normalizer\\ParcelAddressModelNormalizer', 'PPLShipping\\Model\\Model\\LabelPrintModel' => 'PPLShipping\\Model\\Normalizer\\LabelPrintModelNormalizer', 'PPLShipping\\Model\\Model\\CollectionAddressModel' => 'PPLShipping\\Model\\Normalizer\\CollectionAddressModelNormalizer', 'PPLShipping\\Model\\Model\\SenderAddressModel' => 'PPLShipping\\Model\\Normalizer\\SenderAddressModelNormalizer', 'PPLShipping\\Model\\Model\\RecipientAddressModel' => 'PPLShipping\\Model\\Normalizer\\RecipientAddressModelNormalizer', 'PPLShipping\\Model\\Model\\BankAccountModel' => 'PPLShipping\\Model\\Normalizer\\BankAccountModelNormalizer', 'PPLShipping\\Model\\Model\\CartModel' => 'PPLShipping\\Model\\Normalizer\\CartModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentModelNormalizer', 'PPLShipping\\Model\\Model\\CurrencyModel' => 'PPLShipping\\Model\\Normalizer\\CurrencyModelNormalizer', 'PPLShipping\\Model\\Model\\OrderStateModel' => 'PPLShipping\\Model\\Normalizer\\OrderStateModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentPhaseModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentPhaseModelNormalizer', 'PPLShipping\\Model\\Model\\SyncPhasesModel' => 'PPLShipping\\Model\\Normalizer\\SyncPhasesModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModel' => 'PPLShipping\\Model\\Normalizer\\UpdateSyncPhasesModelNormalizer', 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModelPhasesItem' => 'PPLShipping\\Model\\Normalizer\\UpdateSyncPhasesModelPhasesItemNormalizer', 'PPLShipping\\Model\\Model\\CountryModel' => 'PPLShipping\\Model\\Normalizer\\CountryModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentMethodModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentMethodModelNormalizer', 'PPLShipping\\Model\\Model\\NewCollectionModel' => 'PPLShipping\\Model\\Normalizer\\NewCollectionModelNormalizer', 'PPLShipping\\Model\\Model\\CollectionModel' => 'PPLShipping\\Model\\Normalizer\\CollectionModelNormalizer', 'PPLShipping\\Model\\Model\\UpdatePrestaCarrierModel' => 'PPLShipping\\Model\\Normalizer\\UpdatePrestaCarrierModelNormalizer', 'PPLShipping\\Model\\Model\\PrestaCarrierModel' => 'PPLShipping\\Model\\Normalizer\\PrestaCarrierModelNormalizer', 'PPLShipping\\Model\\Model\\ShopModel' => 'PPLShipping\\Model\\Normalizer\\ShopModelNormalizer', 'PPLShipping\\Model\\Model\\ShopGroupModel' => 'PPLShipping\\Model\\Normalizer\\ShopGroupModelNormalizer', 'PPLShipping\\Model\\Model\\ErrorLogItemModel' => 'PPLShipping\\Model\\Normalizer\\ErrorLogItemModelNormalizer', 'PPLShipping\\Model\\Model\\ErrorLogModel' => 'PPLShipping\\Model\\Normalizer\\ErrorLogModelNormalizer', 'PPLShipping\\Model\\Model\\SendErrorLogModel' => 'PPLShipping\\Model\\Normalizer\\SendErrorLogModelNormalizer', 'PPLShipping\\Model\\Model\\ParcelPlacesModel' => 'PPLShipping\\Model\\Normalizer\\ParcelPlacesModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentMethodSettingWeightRuleModelNormalizer', 'PPLShipping\\Model\\Model\\WpErrorModel' => 'PPLShipping\\Model\\Normalizer\\WpErrorModelNormalizer', 'PPLShipping\\Model\\Model\\ShipmentWithAdditionalModel' => 'PPLShipping\\Model\\Normalizer\\ShipmentWithAdditionalModelNormalizer', 'PPLShipping\\Model\\Model\\BatchModel' => 'PPLShipping\\Model\\Normalizer\\BatchModelNormalizer', '\\Jane\\Component\\JsonSchemaRuntime\\Reference' => '\\PPLShipping\\Model\\Runtime\\Normalizer\\ReferenceNormalizer'), $normalizersCache = array();
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return array_key_exists($type, $this->normalizers);
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && array_key_exists(get_class($data), $this->normalizers);
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $normalizerClass = $this->normalizers[get_class($object)];
        $normalizer = $this->getNormalizer($normalizerClass);
        return $normalizer->normalize($object, $format, $context);
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        $denormalizerClass = $this->normalizers[$class];
        $denormalizer = $this->getNormalizer($denormalizerClass);
        return $denormalizer->denormalize($data, $class, $format, $context);
    }
    private function getNormalizer(string $normalizerClass)
    {
        return $this->normalizersCache[$normalizerClass] ?? $this->initNormalizer($normalizerClass);
    }
    private function initNormalizer(string $normalizerClass)
    {
        $normalizer = new $normalizerClass();
        $normalizer->setNormalizer($this->normalizer);
        $normalizer->setDenormalizer($this->denormalizer);
        $this->normalizersCache[$normalizerClass] = $normalizer;
        return $normalizer;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\ProductRulesModel' => false, 'PPLShipping\\Model\\Model\\CategoryRulesModel' => false, 'PPLShipping\\Model\\Model\\ParcelDataModel' => false, 'PPLShipping\\Model\\Model\\ParcelDataModelGps' => false, 'PPLShipping\\Model\\Model\\MyApi2' => false, 'PPLShipping\\Model\\Model\\WhisperSettingModel' => false, 'PPLShipping\\Model\\Model\\WhisperAddressModel' => false, 'PPLShipping\\Model\\Model\\UpdateShipmentModel' => false, 'PPLShipping\\Model\\Model\\UpdateParcelModel' => false, 'PPLShipping\\Model\\Model\\UpdateShipmentSenderModel' => false, 'PPLShipping\\Model\\Model\\UpdateShipmentBankAccountModel' => false, 'PPLShipping\\Model\\Model\\UpdateShipmentParcelModel' => false, 'PPLShipping\\Model\\Model\\CreateShipmentLabelBatchModel' => false, 'PPLShipping\\Model\\Model\\ShipmentLabelRefreshBatchModel' => false, 'PPLShipping\\Model\\Model\\PrepareShipmentBatchModel' => false, 'PPLShipping\\Model\\Model\\PrepareShipmentBatchItemModel' => false, 'PPLShipping\\Model\\Model\\PrepareShipmentBatchReturnModel' => false, 'PPLShipping\\Model\\Model\\RefreshShipmentBatchReturnModel' => false, 'PPLShipping\\Model\\Model\\PackageModel' => false, 'PPLShipping\\Model\\Model\\ParcelAddressModel' => false, 'PPLShipping\\Model\\Model\\LabelPrintModel' => false, 'PPLShipping\\Model\\Model\\CollectionAddressModel' => false, 'PPLShipping\\Model\\Model\\SenderAddressModel' => false, 'PPLShipping\\Model\\Model\\RecipientAddressModel' => false, 'PPLShipping\\Model\\Model\\BankAccountModel' => false, 'PPLShipping\\Model\\Model\\CartModel' => false, 'PPLShipping\\Model\\Model\\ShipmentModel' => false, 'PPLShipping\\Model\\Model\\CurrencyModel' => false, 'PPLShipping\\Model\\Model\\OrderStateModel' => false, 'PPLShipping\\Model\\Model\\ShipmentPhaseModel' => false, 'PPLShipping\\Model\\Model\\SyncPhasesModel' => false, 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModel' => false, 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModelPhasesItem' => false, 'PPLShipping\\Model\\Model\\CountryModel' => false, 'PPLShipping\\Model\\Model\\ShipmentMethodModel' => false, 'PPLShipping\\Model\\Model\\NewCollectionModel' => false, 'PPLShipping\\Model\\Model\\CollectionModel' => false, 'PPLShipping\\Model\\Model\\UpdatePrestaCarrierModel' => false, 'PPLShipping\\Model\\Model\\PrestaCarrierModel' => false, 'PPLShipping\\Model\\Model\\ShopModel' => false, 'PPLShipping\\Model\\Model\\ShopGroupModel' => false, 'PPLShipping\\Model\\Model\\ErrorLogItemModel' => false, 'PPLShipping\\Model\\Model\\ErrorLogModel' => false, 'PPLShipping\\Model\\Model\\SendErrorLogModel' => false, 'PPLShipping\\Model\\Model\\ParcelPlacesModel' => false, 'PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel' => false, 'PPLShipping\\Model\\Model\\WpErrorModel' => false, 'PPLShipping\\Model\\Model\\ShipmentWithAdditionalModel' => false, 'PPLShipping\\Model\\Model\\BatchModel' => false, '\\Jane\\Component\\JsonSchemaRuntime\\Reference' => false);
    }
}