<?php
namespace PPLShipping\tmodule;

class TCategory {
    public function hookDisplayCategoryForm($params)
    {

    }

    public function hookActionCategoryFormSave($params)
    {

    }
}