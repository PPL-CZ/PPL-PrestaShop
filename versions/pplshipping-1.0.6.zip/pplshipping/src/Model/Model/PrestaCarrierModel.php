<?php

namespace PPLShipping\Model\Model;

class PrestaCarrierModel extends \ArrayObject
{
    /**
     * @var array
     */
    protected $initialized = array();
    public function isInitialized($property) : bool
    {
        return array_key_exists($property, $this->initialized);
    }
    /**
     * 
     *
     * @var float
     */
    protected $id;
    /**
     * 
     *
     * @var string
     */
    protected $name;
    /**
     * 
     *
     * @var string|null
     */
    protected $service;
    /**
     * 
     *
     * @var string|null
     */
    protected $module;
    /**
     * 
     *
     * @var bool|null
     */
    protected $active;
    /**
     * 
     *
     * @var ShopModel[]
     */
    protected $shops;
    /**
     * 
     *
     * @return float
     */
    public function getId() : ?float
    {
        return $this->id;
    }
    /**
     * 
     *
     * @param float $id
     *
     * @return self
     */
    public function setId(float $id) : self
    {
        $this->initialized['id'] = true;
        $this->id = $id;
        return $this;
    }
    /**
     * 
     *
     * @return string
     */
    public function getName() : ?string
    {
        return $this->name;
    }
    /**
     * 
     *
     * @param string $name
     *
     * @return self
     */
    public function setName(string $name) : self
    {
        $this->initialized['name'] = true;
        $this->name = $name;
        return $this;
    }
    /**
     * 
     *
     * @return string|null
     */
    public function getService() : ?string
    {
        return $this->service;
    }
    /**
     * 
     *
     * @param string|null $service
     *
     * @return self
     */
    public function setService(?string $service) : self
    {
        $this->initialized['service'] = true;
        $this->service = $service;
        return $this;
    }
    /**
     * 
     *
     * @return string|null
     */
    public function getModule() : ?string
    {
        return $this->module;
    }
    /**
     * 
     *
     * @param string|null $module
     *
     * @return self
     */
    public function setModule(?string $module) : self
    {
        $this->initialized['module'] = true;
        $this->module = $module;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getActive() : ?bool
    {
        return $this->active;
    }
    /**
     * 
     *
     * @param bool|null $active
     *
     * @return self
     */
    public function setActive(?bool $active) : self
    {
        $this->initialized['active'] = true;
        $this->active = $active;
        return $this;
    }
    /**
     * 
     *
     * @return ShopModel[]
     */
    public function getShops() : ?array
    {
        return $this->shops;
    }
    /**
     * 
     *
     * @param ShopModel[] $shops
     *
     * @return self
     */
    public function setShops(array $shops) : self
    {
        $this->initialized['shops'] = true;
        $this->shops = $shops;
        return $this;
    }
}