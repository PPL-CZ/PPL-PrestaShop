<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class ShipmentMethodSettingModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\ShipmentMethodSettingModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\ShipmentMethodSettingModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\ShipmentMethodSettingModel();
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('code', $data)) {
            $object->setCode($data['code']);
            unset($data['code']);
        }
        if (\array_key_exists('costByWeight', $data) && $data['costByWeight'] !== null) {
            $object->setCostByWeight($data['costByWeight']);
            unset($data['costByWeight']);
        }
        elseif (\array_key_exists('costByWeight', $data) && $data['costByWeight'] === null) {
            $object->setCostByWeight(null);
        }
        if (\array_key_exists('parcelBoxes', $data) && $data['parcelBoxes'] !== null) {
            $object->setParcelBoxes($data['parcelBoxes']);
            unset($data['parcelBoxes']);
        }
        elseif (\array_key_exists('parcelBoxes', $data) && $data['parcelBoxes'] === null) {
            $object->setParcelBoxes(null);
        }
        if (\array_key_exists('title', $data) && $data['title'] !== null) {
            $object->setTitle($data['title']);
            unset($data['title']);
        }
        elseif (\array_key_exists('title', $data) && $data['title'] === null) {
            $object->setTitle(null);
        }
        if (\array_key_exists('description', $data) && $data['description'] !== null) {
            $object->setDescription($data['description']);
            unset($data['description']);
        }
        elseif (\array_key_exists('description', $data) && $data['description'] === null) {
            $object->setDescription(null);
        }
        if (\array_key_exists('disablePayments', $data)) {
            $values = array();
            foreach ($data['disablePayments'] as $value) {
                $values[] = $value;
            }
            $object->setDisablePayments($values);
            unset($data['disablePayments']);
        }
        if (\array_key_exists('codPayment', $data) && $data['codPayment'] !== null) {
            $object->setCodPayment($data['codPayment']);
            unset($data['codPayment']);
        }
        elseif (\array_key_exists('codPayment', $data) && $data['codPayment'] === null) {
            $object->setCodPayment(null);
        }
        if (\array_key_exists('isPriceWithDph', $data) && $data['isPriceWithDph'] !== null) {
            $object->setIsPriceWithDph($data['isPriceWithDph']);
            unset($data['isPriceWithDph']);
        }
        elseif (\array_key_exists('isPriceWithDph', $data) && $data['isPriceWithDph'] === null) {
            $object->setIsPriceWithDph(null);
        }
        if (\array_key_exists('weights', $data) && $data['weights'] !== null) {
            $values_1 = array();
            foreach ($data['weights'] as $value_1) {
                $values_1[] = $this->denormalizer->denormalize($value_1, 'PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel', 'json', $context);
            }
            $object->setWeights($values_1);
            unset($data['weights']);
        }
        elseif (\array_key_exists('weights', $data) && $data['weights'] === null) {
            $object->setWeights(null);
        }
        if (\array_key_exists('disabledParcelCountries', $data) && $data['disabledParcelCountries'] !== null) {
            $values_2 = array();
            foreach ($data['disabledParcelCountries'] as $value_2) {
                $values_2[] = $value_2;
            }
            $object->setDisabledParcelCountries($values_2);
            unset($data['disabledParcelCountries']);
        }
        elseif (\array_key_exists('disabledParcelCountries', $data) && $data['disabledParcelCountries'] === null) {
            $object->setDisabledParcelCountries(null);
        }
        if (\array_key_exists('disabledParcelBox', $data) && $data['disabledParcelBox'] !== null) {
            $object->setDisabledParcelBox($data['disabledParcelBox']);
            unset($data['disabledParcelBox']);
        }
        elseif (\array_key_exists('disabledParcelBox', $data) && $data['disabledParcelBox'] === null) {
            $object->setDisabledParcelBox(null);
        }
        if (\array_key_exists('disabledAlzaBox', $data) && $data['disabledAlzaBox'] !== null) {
            $object->setDisabledAlzaBox($data['disabledAlzaBox']);
            unset($data['disabledAlzaBox']);
        }
        elseif (\array_key_exists('disabledAlzaBox', $data) && $data['disabledAlzaBox'] === null) {
            $object->setDisabledAlzaBox(null);
        }
        if (\array_key_exists('disabledParcelShop', $data) && $data['disabledParcelShop'] !== null) {
            $object->setDisabledParcelShop($data['disabledParcelShop']);
            unset($data['disabledParcelShop']);
        }
        elseif (\array_key_exists('disabledParcelShop', $data) && $data['disabledParcelShop'] === null) {
            $object->setDisabledParcelShop(null);
        }
        foreach ($data as $key => $value_3) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value_3;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        $data['code'] = $object->getCode();
        if ($object->isInitialized('costByWeight') && null !== $object->getCostByWeight()) {
            $data['costByWeight'] = $object->getCostByWeight();
        }
        if ($object->isInitialized('parcelBoxes') && null !== $object->getParcelBoxes()) {
            $data['parcelBoxes'] = $object->getParcelBoxes();
        }
        if ($object->isInitialized('title') && null !== $object->getTitle()) {
            $data['title'] = $object->getTitle();
        }
        if ($object->isInitialized('description') && null !== $object->getDescription()) {
            $data['description'] = $object->getDescription();
        }
        if ($object->isInitialized('disablePayments') && null !== $object->getDisablePayments()) {
            $values = array();
            foreach ($object->getDisablePayments() as $value) {
                $values[] = $value;
            }
            $data['disablePayments'] = $values;
        }
        if ($object->isInitialized('codPayment') && null !== $object->getCodPayment()) {
            $data['codPayment'] = $object->getCodPayment();
        }
        if ($object->isInitialized('isPriceWithDph') && null !== $object->getIsPriceWithDph()) {
            $data['isPriceWithDph'] = $object->getIsPriceWithDph();
        }
        if ($object->isInitialized('weights') && null !== $object->getWeights()) {
            $values_1 = array();
            foreach ($object->getWeights() as $value_1) {
                $values_1[] = $this->normalizer->normalize($value_1, 'json', $context);
            }
            $data['weights'] = $values_1;
        }
        if ($object->isInitialized('disabledParcelCountries') && null !== $object->getDisabledParcelCountries()) {
            $values_2 = array();
            foreach ($object->getDisabledParcelCountries() as $value_2) {
                $values_2[] = $value_2;
            }
            $data['disabledParcelCountries'] = $values_2;
        }
        if ($object->isInitialized('disabledParcelBox') && null !== $object->getDisabledParcelBox()) {
            $data['disabledParcelBox'] = $object->getDisabledParcelBox();
        }
        if ($object->isInitialized('disabledAlzaBox') && null !== $object->getDisabledAlzaBox()) {
            $data['disabledAlzaBox'] = $object->getDisabledAlzaBox();
        }
        if ($object->isInitialized('disabledParcelShop') && null !== $object->getDisabledParcelShop()) {
            $data['disabledParcelShop'] = $object->getDisabledParcelShop();
        }
        foreach ($object as $key => $value_3) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value_3;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\ShipmentMethodSettingModel' => false);
    }
}