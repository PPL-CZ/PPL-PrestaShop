<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class ProductRulesModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\ProductRulesModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\ProductRulesModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\ProductRulesModel();
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('pplConfirmAge15', $data) && $data['pplConfirmAge15'] !== null) {
            $object->setPplConfirmAge15($data['pplConfirmAge15']);
            unset($data['pplConfirmAge15']);
        }
        elseif (\array_key_exists('pplConfirmAge15', $data) && $data['pplConfirmAge15'] === null) {
            $object->setPplConfirmAge15(null);
        }
        if (\array_key_exists('pplConfirmAge18', $data) && $data['pplConfirmAge18'] !== null) {
            $object->setPplConfirmAge18($data['pplConfirmAge18']);
            unset($data['pplConfirmAge18']);
        }
        elseif (\array_key_exists('pplConfirmAge18', $data) && $data['pplConfirmAge18'] === null) {
            $object->setPplConfirmAge18(null);
        }
        if (\array_key_exists('pplDisabledParcelBox', $data) && $data['pplDisabledParcelBox'] !== null) {
            $object->setPplDisabledParcelBox($data['pplDisabledParcelBox']);
            unset($data['pplDisabledParcelBox']);
        }
        elseif (\array_key_exists('pplDisabledParcelBox', $data) && $data['pplDisabledParcelBox'] === null) {
            $object->setPplDisabledParcelBox(null);
        }
        if (\array_key_exists('pplDisabledParcelShop', $data) && $data['pplDisabledParcelShop'] !== null) {
            $object->setPplDisabledParcelShop($data['pplDisabledParcelShop']);
            unset($data['pplDisabledParcelShop']);
        }
        elseif (\array_key_exists('pplDisabledParcelShop', $data) && $data['pplDisabledParcelShop'] === null) {
            $object->setPplDisabledParcelShop(null);
        }
        if (\array_key_exists('pplDisabledAlzaBox', $data) && $data['pplDisabledAlzaBox'] !== null) {
            $object->setPplDisabledAlzaBox($data['pplDisabledAlzaBox']);
            unset($data['pplDisabledAlzaBox']);
        }
        elseif (\array_key_exists('pplDisabledAlzaBox', $data) && $data['pplDisabledAlzaBox'] === null) {
            $object->setPplDisabledAlzaBox(null);
        }
        if (\array_key_exists('pplDisabledTransport', $data) && $data['pplDisabledTransport'] !== null) {
            $values = array();
            foreach ($data['pplDisabledTransport'] as $value) {
                $values[] = $value;
            }
            $object->setPplDisabledTransport($values);
            unset($data['pplDisabledTransport']);
        }
        elseif (\array_key_exists('pplDisabledTransport', $data) && $data['pplDisabledTransport'] === null) {
            $object->setPplDisabledTransport(null);
        }
        if (\array_key_exists('pplSizes', $data) && $data['pplSizes'] !== null) {
            $values_1 = array();
            foreach ($data['pplSizes'] as $value_1) {
                $values_1[] = $this->denormalizer->denormalize($value_1, 'PPLShipping\\Model\\Model\\PackageSizeModel', 'json', $context);
            }
            $object->setPplSizes($values_1);
            unset($data['pplSizes']);
        }
        elseif (\array_key_exists('pplSizes', $data) && $data['pplSizes'] === null) {
            $object->setPplSizes(null);
        }
        foreach ($data as $key => $value_2) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value_2;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        if ($object->isInitialized('pplConfirmAge15') && null !== $object->getPplConfirmAge15()) {
            $data['pplConfirmAge15'] = $object->getPplConfirmAge15();
        }
        if ($object->isInitialized('pplConfirmAge18') && null !== $object->getPplConfirmAge18()) {
            $data['pplConfirmAge18'] = $object->getPplConfirmAge18();
        }
        if ($object->isInitialized('pplDisabledParcelBox') && null !== $object->getPplDisabledParcelBox()) {
            $data['pplDisabledParcelBox'] = $object->getPplDisabledParcelBox();
        }
        if ($object->isInitialized('pplDisabledParcelShop') && null !== $object->getPplDisabledParcelShop()) {
            $data['pplDisabledParcelShop'] = $object->getPplDisabledParcelShop();
        }
        if ($object->isInitialized('pplDisabledAlzaBox') && null !== $object->getPplDisabledAlzaBox()) {
            $data['pplDisabledAlzaBox'] = $object->getPplDisabledAlzaBox();
        }
        if ($object->isInitialized('pplDisabledTransport') && null !== $object->getPplDisabledTransport()) {
            $values = array();
            foreach ($object->getPplDisabledTransport() as $value) {
                $values[] = $value;
            }
            $data['pplDisabledTransport'] = $values;
        }
        if ($object->isInitialized('pplSizes') && null !== $object->getPplSizes()) {
            $values_1 = array();
            foreach ($object->getPplSizes() as $value_1) {
                $values_1[] = $this->normalizer->normalize($value_1, 'json', $context);
            }
            $data['pplSizes'] = $values_1;
        }
        foreach ($object as $key => $value_2) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value_2;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\ProductRulesModel' => false);
    }
}