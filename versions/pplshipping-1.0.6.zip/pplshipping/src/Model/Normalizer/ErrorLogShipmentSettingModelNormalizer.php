<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class ErrorLogShipmentSettingModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\ErrorLogShipmentSettingModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\ErrorLogShipmentSettingModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\ErrorLogShipmentSettingModel();
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('name', $data)) {
            $object->setName($data['name']);
            unset($data['name']);
        }
        if (\array_key_exists('shipmentSetting', $data)) {
            $object->setShipmentSetting($this->denormalizer->denormalize($data['shipmentSetting'], 'PPLShipping\\Model\\Model\\ShipmentMethodSettingModel', 'json', $context));
            unset($data['shipmentSetting']);
        }
        if (\array_key_exists('rawBasicData', $data) && $data['rawBasicData'] !== null) {
            $object->setRawBasicData($data['rawBasicData']);
            unset($data['rawBasicData']);
        }
        elseif (\array_key_exists('rawBasicData', $data) && $data['rawBasicData'] === null) {
            $object->setRawBasicData(null);
        }
        if (\array_key_exists('rawWeightData', $data) && $data['rawWeightData'] !== null) {
            $object->setRawWeightData($data['rawWeightData']);
            unset($data['rawWeightData']);
        }
        elseif (\array_key_exists('rawWeightData', $data) && $data['rawWeightData'] === null) {
            $object->setRawWeightData(null);
        }
        if (\array_key_exists('zones', $data)) {
            $object->setZones($data['zones']);
            unset($data['zones']);
        }
        foreach ($data as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        if ($object->isInitialized('name') && null !== $object->getName()) {
            $data['name'] = $object->getName();
        }
        if ($object->isInitialized('shipmentSetting') && null !== $object->getShipmentSetting()) {
            $data['shipmentSetting'] = $this->normalizer->normalize($object->getShipmentSetting(), 'json', $context);
        }
        if ($object->isInitialized('rawBasicData') && null !== $object->getRawBasicData()) {
            $data['rawBasicData'] = $object->getRawBasicData();
        }
        if ($object->isInitialized('rawWeightData') && null !== $object->getRawWeightData()) {
            $data['rawWeightData'] = $object->getRawWeightData();
        }
        if ($object->isInitialized('zones') && null !== $object->getZones()) {
            $data['zones'] = $object->getZones();
        }
        foreach ($object as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\ErrorLogShipmentSettingModel' => false);
    }
}