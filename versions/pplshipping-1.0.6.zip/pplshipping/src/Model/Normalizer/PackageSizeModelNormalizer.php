<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class PackageSizeModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\PackageSizeModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\PackageSizeModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\PackageSizeModel();
        if (\array_key_exists('xSize', $data) && \is_int($data['xSize'])) {
            $data['xSize'] = (double) $data['xSize'];
        }
        if (\array_key_exists('ySize', $data) && \is_int($data['ySize'])) {
            $data['ySize'] = (double) $data['ySize'];
        }
        if (\array_key_exists('zSize', $data) && \is_int($data['zSize'])) {
            $data['zSize'] = (double) $data['zSize'];
        }
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('xSize', $data) && $data['xSize'] !== null) {
            $object->setXSize($data['xSize']);
            unset($data['xSize']);
        }
        elseif (\array_key_exists('xSize', $data) && $data['xSize'] === null) {
            $object->setXSize(null);
        }
        if (\array_key_exists('ySize', $data) && $data['ySize'] !== null) {
            $object->setYSize($data['ySize']);
            unset($data['ySize']);
        }
        elseif (\array_key_exists('ySize', $data) && $data['ySize'] === null) {
            $object->setYSize(null);
        }
        if (\array_key_exists('zSize', $data) && $data['zSize'] !== null) {
            $object->setZSize($data['zSize']);
            unset($data['zSize']);
        }
        elseif (\array_key_exists('zSize', $data) && $data['zSize'] === null) {
            $object->setZSize(null);
        }
        foreach ($data as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        if ($object->isInitialized('xSize') && null !== $object->getXSize()) {
            $data['xSize'] = $object->getXSize();
        }
        if ($object->isInitialized('ySize') && null !== $object->getYSize()) {
            $data['ySize'] = $object->getYSize();
        }
        if ($object->isInitialized('zSize') && null !== $object->getZSize()) {
            $data['zSize'] = $object->getZSize();
        }
        foreach ($object as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\PackageSizeModel' => false);
    }
}