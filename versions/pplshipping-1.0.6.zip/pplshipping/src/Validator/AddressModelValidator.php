<?php
namespace PPLShipping\Validator;

use PPLShipping\Model\Model\RecipientAddressModel;
use PPLShipping\Model\Model\SenderAddressModel;

class AddressModelValidator extends ModelValidator
{
    public function canValidate($model)
    {
        return $model instanceof RecipientAddressModel
            || $model instanceof SenderAddressModel;

    }
    public function validate($model, $error, $path)
    {

        $basePrefix = $model instanceof RecipientAddressModel ? "U příjemce " : "U odesílatele ";

        foreach ([
                     "name" => "{$basePrefix}Osoba/firma musí být vyplněna",
                     "street" => "{$basePrefix}Ulice musí být vyplněna",
                     "city" => "{$basePrefix}Město musí být vyplněno",
                     "country" => "{$basePrefix}Není určen stát"
                 ] as $property => $message) {
            if (!$model->isInitialized($property) || !$model->{"get{$property}"}())
            {
                $error->add($path . ".{$property}", $message);
            }
        }

        if ($model instanceof RecipientAddressModel)
        {
            $name = $model->getName() ?: "";
            $name = join(' ', preg_split('~\s+~', trim($name)));

            if (mb_strlen($name) > 100)
                $error->add($path . '.name', "{$basePrefix} může být jméno max 100 znaků");

            $contact = $model->getContact() ?: "";
            $contact = join(' ', preg_split('~\s+~', trim($contact)));

            if (mb_strlen($contact ?: "") > 50)
                $error->add($path . '.contact', "{$basePrefix} může být kontakt max 50 znaků");

            if (mb_strlen($model->getStreet() ?: "") > 60)
                $error->add($path . '.street', "{$basePrefix} může být ulice max 60 znaků");

            if (mb_strlen($model->getCity() ?: "") > 50)
                $error->add($path . '.city', "{$basePrefix} může být město max 50 znaků");
        }

        if (!self::isZip($model->getCountry(), $model->getZip()))
        {
            $error->add($path . ".zip","{$basePrefix} Je problematické PSČ pro danou zemi");
        }

        if ($model->isInitialized("mail") && $model->getMail())
        {
            if (!filter_var($model->getMail(), FILTER_VALIDATE_EMAIL))
                $error->add("$path.mail", "{$basePrefix} není určen validní mail");
        }

        if ($model->isInitialized("phone") && $model->getPhone())
        {
            $phone = $model->getPhone();
            if (!$this->isPhone($phone)) {
                $error->add("$path.phone", "{$basePrefix} není správné telefonní číslo");
            }
        } else if ($model instanceof RecipientAddressModel) {
            $error->add("$path.phone", "{$basePrefix}  nesmí zůstat prázdné telefonnní číslo");
        }

        if ($model instanceof SenderAddressModel) {
            if (!$model->isInitialized("addressName") || !$model->getAddressName())
            {
                $error->add($path . ".addressName", "U odesílatele je potřeba vyplnit název adresy");
            }
        }
    }
}