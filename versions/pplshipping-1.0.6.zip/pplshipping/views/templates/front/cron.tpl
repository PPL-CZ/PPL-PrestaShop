Zpracováno: {$count}, další: {$next}
