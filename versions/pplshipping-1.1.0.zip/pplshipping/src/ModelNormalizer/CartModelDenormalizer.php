<?php
namespace PPLShipping\ModelNormalizer;

use PPLShipping\Model\Model\CategoryRulesModel;
use PPLShipping\Model\Model\CountryModel;
use PPLShipping\Model\Model\CartModel;
use PPLShipping\Model\Model\ParcelPlacesModel;
use PPLShipping\Model\Model\ProductRulesModel;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Utils\BoxPacker;
use PPLShipping\Setting\MethodSetting;

class CartModelDenormalizer implements DenormalizerInterface
{

    public function denormalize($data, string $type, ?string $format = null, array $context = [])
    {
        /**
         * @var \Cart $data
         */
        $shipmentCartModel = new CartModel();

        $shipmentCartModel->setParcelRequired(false);
        $shipmentCartModel->setMapEnabled(false);
        $shipmentCartModel->setAgeRequired(false);
        $shipmentCartModel->setDisableCod(true);
        $shipmentCartModel->setDisabledByProduct(false);
        $shipmentCartModel->setDisabledByCountry(false);
        $shipmentCartModel->setDisabledByRules(false);
        $shipmentCartModel->setDisabledByWeight(false);
        $shipmentCartModel->setDisabledBySize(false);
        $shipmentCartModel->setParcelShopEnabled(true);
        $shipmentCartModel->setParcelBoxEnabled(true);
        $shipmentCartModel->setAlzaBoxEnabled(true);

        if (!isset($context['carrier']))
            $carrier = new \Carrier($data->id_carrier);
        else
            $carrier = $context['carrier'];

        $code = \Configuration::getGlobalValue("PPLCarrier{$carrier->id_reference}");

        if ($code) {
           $shipmentCartModel->setParcelRequired(pplcz_parcel_required($code));
           $shipmentCartModel->setMapEnabled(pplcz_parcel_required($code));
        }

        if ($shipmentCartModel->getParcelRequired()) {
            $globalMapSetting = MethodSetting::getGlobalSetting()->getMap();
            $enabledMap = $globalMapSetting && $globalMapSetting->getApikey() ? true : false;
            $shipmentCartModel->setMapEnabled($shipmentCartModel->getMapEnabled() && $enabledMap);
            if (!$enabledMap)
                $shipmentCartModel->setDisabledByRules(true);
        }

        $codCountries = pplcz_get_cod_currencies();
        $addressId = $data->id_address_delivery;
        $address = new \Address($addressId);
        $idCountry = $address->id_country;
        $countryCode = null;
        if ($idCountry)
        {
            $country = new \Country($idCountry);
            $countryCode = $country->iso_code;
        }

        $zones = $carrier->getZones();
        $iso_codes = [];
        foreach ($zones as $zone) {
            $zone_countries = \Country::getCountriesByZoneId($zone['id_zone'], (int)\Configuration::get('PS_LANG_DEFAULT'));
            foreach ($zone_countries as $country) {
                if (!in_array($country['iso_code'], $iso_codes)) {
                    $iso_codes[] = $country['iso_code'];
                }
            }
        }
        $pplcountries = array_keys(pplcz_get_allowed_countries());
        $iso_codes = array_intersect($pplcountries, $iso_codes);

        if (!in_array($countryCode, $iso_codes, true)) {
            $shipmentCartModel->setDisabledByCountry(true);
        }

        if (in_array($code, ["SMAR", "SMEU"], true) && !in_array($countryCode, array_keys(pplcz_get_parcel_countries())))
            $shipmentCartModel->setDisabledByCountry(true);

        if (in_array($code, ["SBOX", "SBOD"], true) && $countryCode !== "CZ")
            $shipmentCartModel->setDisabledByCountry(true);

        $max = 100000;
        static $inNormalizer;
        if (!$inNormalizer) {
            $inNormalizer = true;
            $max = $data->getOrderTotal(true, \Cart::BOTH_WITHOUT_SHIPPING );
            $inNormalizer = false;
        }

        $currency = new \Currency($data->id_currency);

        $countryAndBankAccount = pplcz_get_cod_currencies();
        $accountIn = array_filter($countryAndBankAccount, function($item) use ($countryCode, $currency) {
            return $item['country'] ==  $countryCode && $item['currency'] == $currency->iso_code;
        });
        $limits = include __DIR__ . '/../config/limits.php';
        $codName = pplcz_get_cod_name($code);

        $maxCodPrice =  array_values(array_filter($limits['COD'], function ($item) use ($currency, $codName) {
            if ($item['product'] === $codName && $item['currency'] === $currency->iso_code) {
                return true;
            }
            return false;
        }, true));

        if ($shipmentCartModel->getParcelRequired()) {
            /**
             * @var ParcelPlacesModel $parcelplaces
             */
            $parcelplaces = pplcz_denormalize(new \Configuration(), ParcelPlacesModel::class);

            $hasCountries = array_diff(array_keys(pplcz_get_parcel_countries()), $parcelplaces->getDisabledCountries() ?: []);
            $disabledByCountry = !in_array($countryCode, $hasCountries, true);

            $hasCountries = array_intersect(array_values($hasCountries), array_values($iso_codes));

            $shipmentCartModel->setEnabledParcelCountries($hasCountries);

            if (!in_array($countryCode, $hasCountries, true)) {
                $shipmentCartModel->setDisabledByCountry($disabledByCountry);
                $shipmentCartModel->setParcelShopEnabled(false);
                $shipmentCartModel->setParcelBoxEnabled(false);
                $shipmentCartModel->setParcelShopEnabled(false);
            }

            if (in_array($code, ["SBOX", "SBOD"], true)) {
                $shipmentCartModel->setAlzaBoxEnabled(false);
                $shipmentCartModel->setParcelShopEnabled(false);
            }

            if ($parcelplaces->getDisabledParcelShop())
                $shipmentCartModel->setParcelShopEnabled(false);
            if ($parcelplaces->getDisabledParcelBox())
                $shipmentCartModel->setParcelBoxEnabled(false);
            if ($parcelplaces->getDisabledAlzaBox())
                $shipmentCartModel->setAlzaBoxEnabled(false);
        }

        if ($accountIn && $maxCodPrice && $maxCodPrice[0]['max'] > $max)
        {
            $shipmentCartModel->setDisableCod(false);
        }
        $method = MethodSetting::getMethod($code);

        $totalWeight = $data->getTotalWeight();

        if ($method && $method->getMaxWeight() && $totalWeight > $method->getMaxWeight()) {
            $shipmentCartModel->setDisabledByWeight(true);
        }

        $packagesSizes = [];

        foreach ($data->getProducts() as $product) {
            $id_product = $product['id_product'];
            $quantity = (int)$product['cart_quantity'];
            $name = $product['name'];
            //$prestashopProduct = new \Product($id_product);

            $productSize = [];

            $length = $product['depth'];
            $width = $product['width'];
            $height = $product['height'];

            if ($length || $width || $height) {
                $productSize = array_values(array_filter([floatval($length), floatval($width), floatval($height)]));
                $max = max($length, $width, $height);
                if ($max > 0) {
                    while (count($productSize) < 3) {
                        $productSize[] = floatval($max);
                    }
                    $productSize['name'] = $name;
                    $productSize['qty'] = $quantity;
                } else {
                    $productSize = [];
                }
            }

            /**
             * @var ProductRulesModel $rules
             */
            $rules = pplcz_denormalize(\PPLBaseDisabledRule::getByProduct($id_product), ProductRulesModel::class);

            $pplSizes = [];

            if ($method && $method->getMaxDimension()) {

                if ($rules && $rules->getPplSizes()) {
                    foreach ($rules->getPplSizes() as $pplSize) {
                        if ($pplSize) {
                            $current = array_values(array_filter([floatval($pplSize->getYSize()), floatval($pplSize->getZSize()), floatval($pplSize->getXSize())]));
                            $max = floatval(max($current));
                            if ($max > 0) {
                                while (count($current) < 3) {
                                    $current[] = $max;
                                }
                                $current['name'] = $name;
                                $current['qty'] = $quantity;
                                $pplSizes[] = $current;
                            }
                        }
                    }
                }
                if (!$pplSizes && $productSize)
                    $pplSizes[] = $productSize;
            }

            $this->applyRules($shipmentCartModel, $code, $rules );

            $ids = \Product::getProductCategories($id_product);
            $usedCats = [];
            while ($ids)
            {
                $item = array_pop($ids);
                if (in_array((int)$item, $usedCats, true))
                    continue;

                $usedCats[] = (int)$item;
                /**
                 * @var CategoryRulesModel $rules
                 */
                $rules = pplcz_denormalize(\PPLBaseDisabledRule::getByCagetory($item), CategoryRulesModel::class);

                if ($method && $method->getMaxDimension() && !$pplSizes && $rules && $rules->getPplSize()) {
                    $size = $rules->getPplSize();
                    $current = array_values(array_filter([floatval($size->getYSize()), floatval($size->getZSize()), floatval($size->getXSize())]));
                    $max = max($size->getYSize(), $size->getZSize(), $size->getXSize());
                    if ($max > 0) {
                        while (count($current) < 3) {
                            $current[] = floatval($max);
                        }

                        $current['name'] = $name;
                        $current['qty'] = $quantity;
                    }
                    if ($current) {
                        $packagesSizes[] = $current;
                    }
                }

                $this->applyRules($shipmentCartModel, $code, $rules);

                $cat = new \Category($item);
                if ($cat && $cat->id_parent)
                    $ids[] =  (int)$cat->id_parent;
            }

            $packagesSizes = array_merge($packagesSizes, $pplSizes);
        }

        if ($method && $method->getMaxDimension() && $packagesSizes) {
            $sizes = $method->getMaxDimension();
            $max = max($sizes);
            if ($max > 0) {
                while (count($sizes) < 3) {
                    $sizes[] = $max;
                }

                $boxPacker = new BoxPacker();
                $boxPacker->addBox("max", floatval($sizes[0]), floatval($sizes[1]), floatval($sizes[2]));

                if ($method->getMaxPackages())
                    $boxPacker->setMaxPackages($method->getMaxPackages());

                foreach ($packagesSizes as $package) {
                    $boxPacker->addItem($package['name'], floatval($package[0]), floatval($package[1]), floatval($package[2]), floatval($package['qty']));
                }

                $boxPacker->setStackingMode("all");
                $resolved = $boxPacker->pack();

                if (!$resolved || !$resolved['success']) {
                    $shipmentCartModel->setDisabledBySize(true);
                } else {
                    foreach ($resolved['boxes'] as $box) {
                        if ($box['metrics']['shape_efficiency'] < 65) {
                            $shipmentCartModel->setDisabledBySize(true);
                            break;
                        }
                    }
                }
            }
        }

        $shipmentCartModel->setMapEnabled(
            $shipmentCartModel->getMapEnabled()
            && ($shipmentCartModel->getParcelShopEnabled() || $shipmentCartModel->getParcelBoxEnabled() || $shipmentCartModel->getAlzaBoxEnabled())
            && !$shipmentCartModel->getDisabledByCountry()
        );

        if (!$shipmentCartModel->getParcelShopEnabled() && !$shipmentCartModel->getParcelBoxEnabled() && !$shipmentCartModel->getAlzaBoxEnabled() && $shipmentCartModel->getParcelRequired())
        {
            $shipmentCartModel->setDisabledByRules(true);
        }

        if (!$shipmentCartModel->getParcelShopEnabled() && $shipmentCartModel->getAgeRequired() && $countryCode === 'CZ')
        {
            $shipmentCartModel->setDisabledByRules(true);
        }

        return $shipmentCartModel;
    }

    /**
     * @param CategoryRulesModel|ProductRulesModel $rules
     * @return void
     */
    private function applyRules(CartModel $shipmentCartModel, $code, $rules)
    {
        if ($rules) {
            $shipmentCartModel->setAlzaBoxEnabled(!$rules->getPplDisabledAlzaBox() && $shipmentCartModel->getAlzaBoxEnabled());
            $shipmentCartModel->setParcelBoxEnabled(!$rules->getPplDisabledParcelBox() && $shipmentCartModel->getParcelBoxEnabled());
            $shipmentCartModel->setParcelShopEnabled(!$rules->getPplDisabledParcelShop() && $shipmentCartModel->getParcelShopEnabled());
            $shipmentCartModel->setAgeRequired(($rules->getPplConfirmAge15() || $rules->getPplConfirmAge18()) || $shipmentCartModel->getAgeRequired());

            $codeCod = pplcz_get_cod_name($code);
            if ($rules->getPplDisabledTransport() && in_array($codeCod, $rules->getPplDisabledTransport(), true))
                $shipmentCartModel->setDisableCod(true);
            if ($rules->getPplDisabledTransport() && in_array($code, $rules->getPplDisabledTransport(), true))
                $shipmentCartModel->setDisabledByProduct(true);

            if ($shipmentCartModel->getAgeRequired() && $code === "SMAR")
            {
                $shipmentCartModel->setAlzaBoxEnabled(false);
                $shipmentCartModel->setParcelBoxEnabled(false);
            }
        }
    }

    public function supportsDenormalization($data, string $type, ?string $format = null)
    {
        return $data instanceof \Cart && $type === CartModel::class;
    }
}