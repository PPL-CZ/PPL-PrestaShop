<?php
namespace PPLShipping;

class Constants {
    public const API = "PPLApi";

}