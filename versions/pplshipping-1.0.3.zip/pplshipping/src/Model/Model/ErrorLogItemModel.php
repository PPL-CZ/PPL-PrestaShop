<?php

namespace PPLShipping\Model\Model;

class ErrorLogItemModel extends \ArrayObject
{
    /**
     * @var array
     */
    protected $initialized = array();
    public function isInitialized($property) : bool
    {
        return array_key_exists($property, $this->initialized);
    }
    /**
     * 
     *
     * @var string
     */
    protected $trace;
    /**
     * 
     *
     * @return string
     */
    public function getTrace() : ?string
    {
        return $this->trace;
    }
    /**
     * 
     *
     * @param string $trace
     *
     * @return self
     */
    public function setTrace(string $trace) : self
    {
        $this->initialized['trace'] = true;
        $this->trace = $trace;
        return $this;
    }
}