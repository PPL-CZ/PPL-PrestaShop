<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class UpdateSyncPhasesModelPhasesItemNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModelPhasesItem';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\UpdateSyncPhasesModelPhasesItem';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\UpdateSyncPhasesModelPhasesItem();
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('code', $data) && $data['code'] !== null) {
            $object->setCode($data['code']);
            unset($data['code']);
        }
        elseif (\array_key_exists('code', $data) && $data['code'] === null) {
            $object->setCode(null);
        }
        if (\array_key_exists('watch', $data) && $data['watch'] !== null) {
            $object->setWatch($data['watch']);
            unset($data['watch']);
        }
        elseif (\array_key_exists('watch', $data) && $data['watch'] === null) {
            $object->setWatch(null);
        }
        if (\array_key_exists('orderState', $data) && $data['orderState'] !== null) {
            $object->setOrderState($data['orderState']);
            unset($data['orderState']);
        }
        elseif (\array_key_exists('orderState', $data) && $data['orderState'] === null) {
            $object->setOrderState(null);
        }
        foreach ($data as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        $data['code'] = $object->getCode();
        $data['watch'] = $object->getWatch();
        if ($object->isInitialized('orderState') && null !== $object->getOrderState()) {
            $data['orderState'] = $object->getOrderState();
        }
        foreach ($object as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\UpdateSyncPhasesModelPhasesItem' => false);
    }
}