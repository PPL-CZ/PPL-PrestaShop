<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class PrestaCarrierModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\PrestaCarrierModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\PrestaCarrierModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\PrestaCarrierModel();
        if (\array_key_exists('id', $data) && \is_int($data['id'])) {
            $data['id'] = (double) $data['id'];
        }
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('id', $data)) {
            $object->setId($data['id']);
            unset($data['id']);
        }
        if (\array_key_exists('name', $data)) {
            $object->setName($data['name']);
            unset($data['name']);
        }
        if (\array_key_exists('service', $data) && $data['service'] !== null) {
            $object->setService($data['service']);
            unset($data['service']);
        }
        elseif (\array_key_exists('service', $data) && $data['service'] === null) {
            $object->setService(null);
        }
        if (\array_key_exists('shops', $data)) {
            $values = array();
            foreach ($data['shops'] as $value) {
                $values[] = $this->denormalizer->denormalize($value, 'PPLShipping\\Model\\Model\\ShopModel', 'json', $context);
            }
            $object->setShops($values);
            unset($data['shops']);
        }
        foreach ($data as $key => $value_1) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value_1;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        $data['id'] = $object->getId();
        $data['name'] = $object->getName();
        if ($object->isInitialized('service') && null !== $object->getService()) {
            $data['service'] = $object->getService();
        }
        $values = array();
        foreach ($object->getShops() as $value) {
            $values[] = $this->normalizer->normalize($value, 'json', $context);
        }
        $data['shops'] = $values;
        foreach ($object as $key => $value_1) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value_1;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\PrestaCarrierModel' => false);
    }
}