<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class CartModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\CartModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\CartModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\CartModel();
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('parcelRequired', $data) && $data['parcelRequired'] !== null) {
            $object->setParcelRequired($data['parcelRequired']);
            unset($data['parcelRequired']);
        }
        elseif (\array_key_exists('parcelRequired', $data) && $data['parcelRequired'] === null) {
            $object->setParcelRequired(null);
        }
        if (\array_key_exists('mapEnabled', $data) && $data['mapEnabled'] !== null) {
            $object->setMapEnabled($data['mapEnabled']);
            unset($data['mapEnabled']);
        }
        elseif (\array_key_exists('mapEnabled', $data) && $data['mapEnabled'] === null) {
            $object->setMapEnabled(null);
        }
        if (\array_key_exists('ageRequired', $data) && $data['ageRequired'] !== null) {
            $object->setAgeRequired($data['ageRequired']);
            unset($data['ageRequired']);
        }
        elseif (\array_key_exists('ageRequired', $data) && $data['ageRequired'] === null) {
            $object->setAgeRequired(null);
        }
        if (\array_key_exists('disableCod', $data) && $data['disableCod'] !== null) {
            $object->setDisableCod($data['disableCod']);
            unset($data['disableCod']);
        }
        elseif (\array_key_exists('disableCod', $data) && $data['disableCod'] === null) {
            $object->setDisableCod(null);
        }
        if (\array_key_exists('parcelBoxEnabled', $data) && $data['parcelBoxEnabled'] !== null) {
            $object->setParcelBoxEnabled($data['parcelBoxEnabled']);
            unset($data['parcelBoxEnabled']);
        }
        elseif (\array_key_exists('parcelBoxEnabled', $data) && $data['parcelBoxEnabled'] === null) {
            $object->setParcelBoxEnabled(null);
        }
        if (\array_key_exists('parcelShopEnabled', $data) && $data['parcelShopEnabled'] !== null) {
            $object->setParcelShopEnabled($data['parcelShopEnabled']);
            unset($data['parcelShopEnabled']);
        }
        elseif (\array_key_exists('parcelShopEnabled', $data) && $data['parcelShopEnabled'] === null) {
            $object->setParcelShopEnabled(null);
        }
        if (\array_key_exists('alzaBoxEnabled', $data) && $data['alzaBoxEnabled'] !== null) {
            $object->setAlzaBoxEnabled($data['alzaBoxEnabled']);
            unset($data['alzaBoxEnabled']);
        }
        elseif (\array_key_exists('alzaBoxEnabled', $data) && $data['alzaBoxEnabled'] === null) {
            $object->setAlzaBoxEnabled(null);
        }
        if (\array_key_exists('disabledByRules', $data) && $data['disabledByRules'] !== null) {
            $object->setDisabledByRules($data['disabledByRules']);
            unset($data['disabledByRules']);
        }
        elseif (\array_key_exists('disabledByRules', $data) && $data['disabledByRules'] === null) {
            $object->setDisabledByRules(null);
        }
        if (\array_key_exists('disabledByCountry', $data)) {
            $object->setDisabledByCountry($data['disabledByCountry']);
            unset($data['disabledByCountry']);
        }
        if (\array_key_exists('disabledByProduct', $data)) {
            $object->setDisabledByProduct($data['disabledByProduct']);
            unset($data['disabledByProduct']);
        }
        if (\array_key_exists('enabledParcelCountries', $data) && $data['enabledParcelCountries'] !== null) {
            $values = array();
            foreach ($data['enabledParcelCountries'] as $value) {
                $values[] = $value;
            }
            $object->setEnabledParcelCountries($values);
            unset($data['enabledParcelCountries']);
        }
        elseif (\array_key_exists('enabledParcelCountries', $data) && $data['enabledParcelCountries'] === null) {
            $object->setEnabledParcelCountries(null);
        }
        foreach ($data as $key => $value_1) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value_1;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        if ($object->isInitialized('parcelRequired') && null !== $object->getParcelRequired()) {
            $data['parcelRequired'] = $object->getParcelRequired();
        }
        if ($object->isInitialized('mapEnabled') && null !== $object->getMapEnabled()) {
            $data['mapEnabled'] = $object->getMapEnabled();
        }
        if ($object->isInitialized('ageRequired') && null !== $object->getAgeRequired()) {
            $data['ageRequired'] = $object->getAgeRequired();
        }
        if ($object->isInitialized('disableCod') && null !== $object->getDisableCod()) {
            $data['disableCod'] = $object->getDisableCod();
        }
        if ($object->isInitialized('parcelBoxEnabled') && null !== $object->getParcelBoxEnabled()) {
            $data['parcelBoxEnabled'] = $object->getParcelBoxEnabled();
        }
        if ($object->isInitialized('parcelShopEnabled') && null !== $object->getParcelShopEnabled()) {
            $data['parcelShopEnabled'] = $object->getParcelShopEnabled();
        }
        if ($object->isInitialized('alzaBoxEnabled') && null !== $object->getAlzaBoxEnabled()) {
            $data['alzaBoxEnabled'] = $object->getAlzaBoxEnabled();
        }
        if ($object->isInitialized('disabledByRules') && null !== $object->getDisabledByRules()) {
            $data['disabledByRules'] = $object->getDisabledByRules();
        }
        if ($object->isInitialized('disabledByCountry') && null !== $object->getDisabledByCountry()) {
            $data['disabledByCountry'] = $object->getDisabledByCountry();
        }
        if ($object->isInitialized('disabledByProduct') && null !== $object->getDisabledByProduct()) {
            $data['disabledByProduct'] = $object->getDisabledByProduct();
        }
        if ($object->isInitialized('enabledParcelCountries') && null !== $object->getEnabledParcelCountries()) {
            $values = array();
            foreach ($object->getEnabledParcelCountries() as $value) {
                $values[] = $value;
            }
            $data['enabledParcelCountries'] = $values;
        }
        foreach ($object as $key => $value_1) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value_1;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\CartModel' => false);
    }
}