<?php

namespace PPLShipping\Model\Normalizer;

use PPLShipping\Jane\Component\JsonSchemaRuntime\Reference;
use PPLShipping\Model\Runtime\Normalizer\CheckArray;
use PPLShipping\Model\Runtime\Normalizer\ValidatorTrait;
use PPLShipping\Symfony\Component\Serializer\Exception\InvalidArgumentException;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use PPLShipping\Symfony\Component\Serializer\Normalizer\NormalizerInterface;
class ShipmentMethodSettingWeightRuleModelNormalizer implements DenormalizerInterface, NormalizerInterface, DenormalizerAwareInterface, NormalizerAwareInterface
{
    use DenormalizerAwareTrait;
    use NormalizerAwareTrait;
    use CheckArray;
    use ValidatorTrait;
    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = array()) : bool
    {
        return $type === 'PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel';
    }
    public function supportsNormalization($data, ?string $format = null, array $context = array()) : bool
    {
        return is_object($data) && get_class($data) === 'PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel';
    }
    /**
     * @return mixed
     */
    public function denormalize($data, string $class, ?string $format = null, array $context = array())
    {
        if (isset($data['$ref'])) {
            return new Reference($data['$ref'], $context['document-origin']);
        }
        if (isset($data['$recursiveRef'])) {
            return new Reference($data['$recursiveRef'], $context['document-origin']);
        }
        $object = new \PPLShipping\Model\Model\ShipmentMethodSettingWeightRuleModel();
        if (\array_key_exists('from', $data) && \is_int($data['from'])) {
            $data['from'] = (double) $data['from'];
        }
        if (\array_key_exists('to', $data) && \is_int($data['to'])) {
            $data['to'] = (double) $data['to'];
        }
        if (null === $data || false === \is_array($data)) {
            return $object;
        }
        if (\array_key_exists('from', $data) && $data['from'] !== null) {
            $object->setFrom($data['from']);
            unset($data['from']);
        }
        elseif (\array_key_exists('from', $data) && $data['from'] === null) {
            $object->setFrom(null);
        }
        if (\array_key_exists('to', $data) && $data['to'] !== null) {
            $object->setTo($data['to']);
            unset($data['to']);
        }
        elseif (\array_key_exists('to', $data) && $data['to'] === null) {
            $object->setTo(null);
        }
        if (\array_key_exists('disabledParcelBox', $data) && $data['disabledParcelBox'] !== null) {
            $object->setDisabledParcelBox($data['disabledParcelBox']);
            unset($data['disabledParcelBox']);
        }
        elseif (\array_key_exists('disabledParcelBox', $data) && $data['disabledParcelBox'] === null) {
            $object->setDisabledParcelBox(null);
        }
        if (\array_key_exists('disabledAlzaBox', $data)) {
            $object->setDisabledAlzaBox($data['disabledAlzaBox']);
            unset($data['disabledAlzaBox']);
        }
        if (\array_key_exists('disabledParcelShop', $data) && $data['disabledParcelShop'] !== null) {
            $object->setDisabledParcelShop($data['disabledParcelShop']);
            unset($data['disabledParcelShop']);
        }
        elseif (\array_key_exists('disabledParcelShop', $data) && $data['disabledParcelShop'] === null) {
            $object->setDisabledParcelShop(null);
        }
        foreach ($data as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $object[$key] = $value;
            }
        }
        return $object;
    }
    /**
     * @return array|string|int|float|bool|\ArrayObject|null
     */
    public function normalize($object, ?string $format = null, array $context = array())
    {
        $data = array();
        if ($object->isInitialized('from') && null !== $object->getFrom()) {
            $data['from'] = $object->getFrom();
        }
        if ($object->isInitialized('to') && null !== $object->getTo()) {
            $data['to'] = $object->getTo();
        }
        if ($object->isInitialized('disabledParcelBox') && null !== $object->getDisabledParcelBox()) {
            $data['disabledParcelBox'] = $object->getDisabledParcelBox();
        }
        if ($object->isInitialized('disabledAlzaBox') && null !== $object->getDisabledAlzaBox()) {
            $data['disabledAlzaBox'] = $object->getDisabledAlzaBox();
        }
        if ($object->isInitialized('disabledParcelShop') && null !== $object->getDisabledParcelShop()) {
            $data['disabledParcelShop'] = $object->getDisabledParcelShop();
        }
        foreach ($object as $key => $value) {
            if (preg_match('/.*/', (string) $key)) {
                $data[$key] = $value;
            }
        }
        return $data;
    }
    public function getSupportedTypes(?string $format = null) : array
    {
        return array('PPLShipping\\Model\\Model\\ShipmentMethodSettingWeightRuleModel' => false);
    }
}