<?php

namespace PPLShipping\Model\Model;

class CartModel extends \ArrayObject
{
    /**
     * @var array
     */
    protected $initialized = array();
    public function isInitialized($property) : bool
    {
        return array_key_exists($property, $this->initialized);
    }
    /**
     * 
     *
     * @var bool|null
     */
    protected $parcelRequired;
    /**
     * 
     *
     * @var bool|null
     */
    protected $mapEnabled;
    /**
     * 
     *
     * @var bool|null
     */
    protected $ageRequired;
    /**
     * 
     *
     * @var bool|null
     */
    protected $disableCod;
    /**
     * 
     *
     * @var bool|null
     */
    protected $parcelBoxEnabled;
    /**
     * 
     *
     * @var bool|null
     */
    protected $parcelShopEnabled;
    /**
     * 
     *
     * @var bool|null
     */
    protected $alzaBoxEnabled;
    /**
     * 
     *
     * @var bool|null
     */
    protected $disabledByRules;
    /**
     * 
     *
     * @var bool
     */
    protected $disabledByCountry;
    /**
     * 
     *
     * @var bool
     */
    protected $disabledByProduct;
    /**
     * 
     *
     * @var string[]|null
     */
    protected $enabledParcelCountries;
    /**
     * 
     *
     * @return bool|null
     */
    public function getParcelRequired() : ?bool
    {
        return $this->parcelRequired;
    }
    /**
     * 
     *
     * @param bool|null $parcelRequired
     *
     * @return self
     */
    public function setParcelRequired(?bool $parcelRequired) : self
    {
        $this->initialized['parcelRequired'] = true;
        $this->parcelRequired = $parcelRequired;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getMapEnabled() : ?bool
    {
        return $this->mapEnabled;
    }
    /**
     * 
     *
     * @param bool|null $mapEnabled
     *
     * @return self
     */
    public function setMapEnabled(?bool $mapEnabled) : self
    {
        $this->initialized['mapEnabled'] = true;
        $this->mapEnabled = $mapEnabled;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getAgeRequired() : ?bool
    {
        return $this->ageRequired;
    }
    /**
     * 
     *
     * @param bool|null $ageRequired
     *
     * @return self
     */
    public function setAgeRequired(?bool $ageRequired) : self
    {
        $this->initialized['ageRequired'] = true;
        $this->ageRequired = $ageRequired;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getDisableCod() : ?bool
    {
        return $this->disableCod;
    }
    /**
     * 
     *
     * @param bool|null $disableCod
     *
     * @return self
     */
    public function setDisableCod(?bool $disableCod) : self
    {
        $this->initialized['disableCod'] = true;
        $this->disableCod = $disableCod;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getParcelBoxEnabled() : ?bool
    {
        return $this->parcelBoxEnabled;
    }
    /**
     * 
     *
     * @param bool|null $parcelBoxEnabled
     *
     * @return self
     */
    public function setParcelBoxEnabled(?bool $parcelBoxEnabled) : self
    {
        $this->initialized['parcelBoxEnabled'] = true;
        $this->parcelBoxEnabled = $parcelBoxEnabled;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getParcelShopEnabled() : ?bool
    {
        return $this->parcelShopEnabled;
    }
    /**
     * 
     *
     * @param bool|null $parcelShopEnabled
     *
     * @return self
     */
    public function setParcelShopEnabled(?bool $parcelShopEnabled) : self
    {
        $this->initialized['parcelShopEnabled'] = true;
        $this->parcelShopEnabled = $parcelShopEnabled;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getAlzaBoxEnabled() : ?bool
    {
        return $this->alzaBoxEnabled;
    }
    /**
     * 
     *
     * @param bool|null $alzaBoxEnabled
     *
     * @return self
     */
    public function setAlzaBoxEnabled(?bool $alzaBoxEnabled) : self
    {
        $this->initialized['alzaBoxEnabled'] = true;
        $this->alzaBoxEnabled = $alzaBoxEnabled;
        return $this;
    }
    /**
     * 
     *
     * @return bool|null
     */
    public function getDisabledByRules() : ?bool
    {
        return $this->disabledByRules;
    }
    /**
     * 
     *
     * @param bool|null $disabledByRules
     *
     * @return self
     */
    public function setDisabledByRules(?bool $disabledByRules) : self
    {
        $this->initialized['disabledByRules'] = true;
        $this->disabledByRules = $disabledByRules;
        return $this;
    }
    /**
     * 
     *
     * @return bool
     */
    public function getDisabledByCountry() : ?bool
    {
        return $this->disabledByCountry;
    }
    /**
     * 
     *
     * @param bool $disabledByCountry
     *
     * @return self
     */
    public function setDisabledByCountry(bool $disabledByCountry) : self
    {
        $this->initialized['disabledByCountry'] = true;
        $this->disabledByCountry = $disabledByCountry;
        return $this;
    }
    /**
     * 
     *
     * @return bool
     */
    public function getDisabledByProduct() : ?bool
    {
        return $this->disabledByProduct;
    }
    /**
     * 
     *
     * @param bool $disabledByProduct
     *
     * @return self
     */
    public function setDisabledByProduct(bool $disabledByProduct) : self
    {
        $this->initialized['disabledByProduct'] = true;
        $this->disabledByProduct = $disabledByProduct;
        return $this;
    }
    /**
     * 
     *
     * @return string[]|null
     */
    public function getEnabledParcelCountries() : ?array
    {
        return $this->enabledParcelCountries;
    }
    /**
     * 
     *
     * @param string[]|null $enabledParcelCountries
     *
     * @return self
     */
    public function setEnabledParcelCountries(?array $enabledParcelCountries) : self
    {
        $this->initialized['enabledParcelCountries'] = true;
        $this->enabledParcelCountries = $enabledParcelCountries;
        return $this;
    }
}