<?php

namespace PPLShipping\Model\Model;

class UpdatePrestaCarrierModel extends \ArrayObject
{
    /**
     * @var array
     */
    protected $initialized = array();
    public function isInitialized($property) : bool
    {
        return array_key_exists($property, $this->initialized);
    }
    /**
     * 
     *
     * @var string|null
     */
    protected $serviceCode;
    /**
     * 
     *
     * @var float
     */
    protected $carrierId;
    /**
     * 
     *
     * @return string|null
     */
    public function getServiceCode() : ?string
    {
        return $this->serviceCode;
    }
    /**
     * 
     *
     * @param string|null $serviceCode
     *
     * @return self
     */
    public function setServiceCode(?string $serviceCode) : self
    {
        $this->initialized['serviceCode'] = true;
        $this->serviceCode = $serviceCode;
        return $this;
    }
    /**
     * 
     *
     * @return float
     */
    public function getCarrierId() : ?float
    {
        return $this->carrierId;
    }
    /**
     * 
     *
     * @param float $carrierId
     *
     * @return self
     */
    public function setCarrierId(float $carrierId) : self
    {
        $this->initialized['carrierId'] = true;
        $this->carrierId = $carrierId;
        return $this;
    }
}