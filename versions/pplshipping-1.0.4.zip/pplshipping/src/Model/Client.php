<?php

namespace PPLShipping\Model;

class Client extends \PPLShipping\Model\Runtime\Client\Client
{
    public static function create($httpClient = null, array $additionalPlugins = array(), array $additionalNormalizers = array())
    {
        if (null === $httpClient) {
            $httpClient = \PPLShipping\Http\Discovery\Psr18ClientDiscovery::find();
            $plugins = array();
            if (count($additionalPlugins) > 0) {
                $plugins = array_merge($plugins, $additionalPlugins);
            }
            $httpClient = new \PPLShipping\Http\Client\Common\PluginClient($httpClient, $plugins);
        }
        $requestFactory = \PPLShipping\Http\Discovery\Psr17FactoryDiscovery::findRequestFactory();
        $streamFactory = \PPLShipping\Http\Discovery\Psr17FactoryDiscovery::findStreamFactory();
        $normalizers = array(new PPLShipping\Symfony\Component\Serializer\Normalizer\ArrayDenormalizer(), new \PPLShipping\Model\Normalizer\JaneObjectNormalizer());
        if (count($additionalNormalizers) > 0) {
            $normalizers = array_merge($normalizers, $additionalNormalizers);
        }
        $serializer = new \PPLShipping\Symfony\Component\Serializer\Serializer($normalizers, array(new \PPLShipping\Symfony\Component\Serializer\Encoder\JsonEncoder(new \PPLShipping\Symfony\Component\Serializer\Encoder\JsonEncode(), new \PPLShipping\Symfony\Component\Serializer\Encoder\JsonDecode(array('json_decode_associative' => true)))));
        return new static($httpClient, $requestFactory, $serializer, $streamFactory);
    }
}